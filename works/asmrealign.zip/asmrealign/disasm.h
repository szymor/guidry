int disasm(System *sys, unsigned long addr, CODE **cptr, int replace);
int analyze(System *sys, unsigned long addr, int retstop, unsigned long end_eip, int max_instr, int replace);