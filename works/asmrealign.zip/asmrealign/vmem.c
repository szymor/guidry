// vmem - handles our virtual memory functions
// just use MemReadData and MemWriteData and it'll throw it into pages of PAGE_SIZE size.. etc

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include "structs.h"
#include "vmem.h"
#include "links.h"
#include "utils.h"


#define PAGE_SIZE 4096*2*2

unsigned long roundupto(unsigned long n, unsigned long block){
    if(block <= 1) return n;
    block--;
    return (n + block) & ~block;
}


MemPage *MemPagePtr(System *sys, unsigned long addr) {
    MemPage *mptr;
    int round = roundupto(addr, PAGE_SIZE); // round up to 64k pages
    for (mptr = sys->pages; mptr != NULL; mptr = mptr->next) {
        if (round == mptr->round)
            return mptr;
    }
    // couldnt find so allocate..
    if ((mptr = (MemPage *)l_add((LINK **)&sys->pages, sizeof(MemPage))) == NULL) {
        printf("MemPagePtr: alloc fail");
        exit(-1);
    }

    mptr->round = round;
    mptr->size = PAGE_SIZE;
    mptr->data = mymalloc(PAGE_SIZE);
    memset(mptr->data, 0xFE, PAGE_SIZE);
    
    return mptr;
}

//reads data out of the virutal memory
unsigned char *MemDataRead(System *sys, unsigned long addr, unsigned char *result, int len) {
    MemPage *mptr;
    unsigned long i;
    unsigned long pageaddr;
    int round;
    for (i = 0; i < len; i++) {
        // determine which page
        round = roundupto(addr+i, PAGE_SIZE);
        mptr = MemPagePtr(sys,addr+i);
        // determine location on page
        pageaddr = (addr+i) - (mptr->round - PAGE_SIZE);
        // read byte
    
        result[i] = mptr->data[pageaddr];
    }
    return result;
}

unsigned long MemDataWrite(System *sys, unsigned long addr, unsigned char *data, int len) {
    MemPage *mptr;
    unsigned long i;
    unsigned long pageaddr;
    unsigned long count = 0;
    int round;
    for (i = 0; i < len; i++) {
        // determine which page
        round = roundupto(addr+i, PAGE_SIZE);
        mptr = MemPagePtr(sys,addr+i);
        // determine location on page
        pageaddr = (addr+i) - (mptr->round - PAGE_SIZE);
        // write byte
        mptr->data[pageaddr] = data[i];
        count++;
    }
    return count;
}

