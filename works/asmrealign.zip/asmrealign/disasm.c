#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include <sys/stat.h>
#include "links.h"
#include "pe.h"
#include "structs.h"
#include "vmem.h"
#include "udis86.h"
#include "code.h"


// disassemble a single instruction at an address... and return the address of the CODE structure
int disasm(System *sys, unsigned long addr, CODE **cptr, int replace) {
    unsigned char data[13];
    ud_t ud_obj;
    int len=0;
    int i;
    
    ud_init(&ud_obj);
    
    ud_set_mode(&ud_obj, 32);
    ud_set_syntax(&ud_obj, UD_SYN_INTEL);
    ud_set_pc(&ud_obj, addr);
    
    // a single instruction has the max length of 13
    MemDataRead(sys, addr, &data, 13);
    ud_set_input_buffer(&ud_obj, data, 13);
    
    //printf("disasm hex -");for (i = 0; i < 13; i++) { printf("%02x ", (unsigned char)data[i]); } printf("\n");
    
    if ((len = ud_disassemble(&ud_obj)) > 0) {
        unsigned long offset = ud_insn_off(&ud_obj);
        unsigned long raw_offset = offset - ((unsigned long)sys->code_addr + (unsigned long)sys->baseaddr);
        unsigned long origaddr = offset;
        int size = ud_insn_len(&ud_obj);
        
        printf("[%lu:%d] %s\n", offset, size, ud_insn_asm(&ud_obj));
        
        if (strcmp(ud_insn_asm(&ud_obj), "invalid")==0) return 0;
        *cptr = code_add(sys, offset, raw_offset, origaddr, size, ud_insn_asm(&ud_obj), ud_insn_ptr(&ud_obj), replace, &ud_obj);
        return len;
    } else
        return 0;
}


// disassemble instructions starting at an address and stopping at ret, max eip, or max instructions disassembled
// replace determines if we deleted/overwrite previous CODE structures..
// if you analyze the entire text section from top to bottom without beginning at an entry point, or following
// through the code and jmps/calls then some things could possibly be unaligned.. this allows you to replace those
int analyze(System *sys, unsigned long addr, int retstop, unsigned long end_eip, int max_instr, int replace) {
    CODE *cptr, *cptr2;
    ud_t ud_obj;
    unsigned long eip;
    unsigned long r = 0;
    unsigned long total = 0;
    unsigned long already = 0;

    
    eip = addr;
    
    do {
        cptr2 = findaddr(sys, eip);
        if (cptr2) {
            if (already++ > 10) break;
        } else {
            already = 0;
        }
        
        r = disasm(sys, eip, &cptr, replace);
        
        if (r == 0) break;
        eip += r;
        total += r;
        
        if (retstop == 1) {
            if (strstr(cptr->asmcode, "ret")) break;
        }
        if ((max_instr > 0) && (eip > (addr + max_instr))) {
            printf("analyze() stopping after %d instructions\n", max_instr);
            break;
        }
        if ((end_eip > 0) && (eip > sys->end_eip)) {
            printf("analyze() stopping because we hit end eip %lu\n", end_eip);
            break;
        }
    } while (r);
    
    return total;
}
