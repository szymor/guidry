
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include <sys/stat.h>
#include "links.h"
#include "pe.h"
#include "structs.h"
#include "vmem.h"
#include "udis86.h"
#include "utils.h"


char funcbegin[] = "\x55\x8B\xEC";
char *realign[] = { "call","jmp","jz","jnz","jbe","jle","jge","ja","jb","js","jl","jg","jnp","jo","jns","jp","jecxz",NULL};

Funcs *Func_Find(System *sys, unsigned long addr) {
    Funcs *fptr;
    for (fptr = sys->funcs; fptr; fptr = fptr->next) {
        if (fptr->addr == addr) return fptr;
    }
    return NULL;
}

Funcs *Func_Add(System *sys, unsigned long addr) {
    Funcs *fptr;
    fptr = Func_Find(sys, addr);
    if (fptr != NULL) return fptr;
    fptr = (Funcs *)l_add((LINK **)&sys->funcs, sizeof(Funcs));
    fptr->addr = addr;
    return fptr;
}

// deletes some information inside of the CODE structure preparing for it to be deleted
void codeunlink(CODE *cptr) {
    if (cptr->asmcode) free(cptr->asmcode);
    if (cptr->raw) free(cptr->raw);
    if (cptr->additions) codeunlink(cptr->additions);
}

// finds a CODE structure which belongs to a specific addr
CODE *findaddr(System *sys, unsigned long addr) {
    CODE *cptr = sys->code;
    
    for (cptr = sys->code; cptr != NULL; cptr = cptr->next) {
        if ((addr >= cptr->origaddr) && (addr < (cptr->origaddr + cptr->size)))
            return cptr;
    }
    return NULL;
}

// delete all CODE structures belonging to an address(es)
void deladdr(System *sys, void *addr, int size) {
    int i, c= 0, which;
    CODE *cptr, *nptr, *pptr;
    Queue *qptr;
    
    for (i = 0; i < size; i++) {
        cptr = findaddr(sys, addr + i);
    
        // remove from map
        if (cptr != NULL)
        if (((cptr->fileoffset + i) > 0) && (cptr->fileoffset + i) < sys->exe_size)
            sys->map[cptr->fileoffset] = NULL;
        
        for (qptr = sys->queue; qptr != NULL; qptr = qptr->next)
            if (qptr->addr == addr)
                qptr->analyzed=1;
        
        if (cptr != NULL) {
            codeunlink(cptr);
            
            if (pptr = cptr->prev) {
                if (cptr->next)
                    pptr->next = cptr->next;
            } else
                sys->code = cptr->next;
            
            if (nptr = cptr->next) {
                nptr->prev = pptr;
            }
            free(cptr);
            
            c++;
        }
    }
}



// calculate the destination address for jumps or calls
unsigned long destaddr(CODE *cptr) {
    if (cptr == NULL) return 0;
    unsigned long toaddr = cptr->origaddr + cptr->size;
    switch (cptr->ud_obj.operand[0].size) {
        case 8:
            toaddr += (cptr->ud_obj.operand[0].lval.sbyte & 0xff);
            break;
        case 16:
            toaddr += (cptr->ud_obj.operand[0].lval.sword & 0xffff);
            break;
        case 32:
            toaddr += (cptr->ud_obj.operand[0].lval.sdword);
            break;
            
    }
    
    // return 0 to not have it adjusted (should be changed later to also modify deferences if we changed their section)
    switch (cptr->ud_obj.operand[0].type) {
        case UD_OP_REG:
            return 0;
            break;
        case UD_OP_MEM:
            return 0;
            return (cptr->ud_obj.operand[0].lval.sdword);
            //return 0x00000000;
            break;
        case UD_OP_PTR:
            break;
        case UD_OP_IMM:
            break;
        case UD_OP_JIMM:
            return toaddr;
            break;
        case UD_OP_CONST:
            break;
    }

    return 0;
}


// adds a disassembled instruction into the CODE structures.. 
CODE *code_add(System *sys, int offset, int fileoffset, unsigned long origaddr, int size, unsigned char *asmcode, unsigned char *raw, int replace, ud_t *ud_obj) {
    CODE *cptr;
    int i;
    int found = 0;
    Ref *rptr;
    Funcs *fptr;
    
    
    // check if alrewady exists
    if (replace == 0) {
        for (i = 0; i < size; i++)
            if ((cptr = findaddr(sys, origaddr + i)) != NULL) {
                printf("in memory already! %lu %lu %d\n", origaddr, origaddr+i, size);
                return NULL;
            }
    }
    
    if ((cptr = findaddr(sys, origaddr)) != NULL) {
        if (replace == 1) {
            if (asmcode && cptr->asmcode && strcmp(cptr->asmcode, asmcode) != 0) {
                printf("deleted %lu - replacing [%s \\ %s] / [%s // %x]\n",
                       origaddr, cptr->asmcode, asmcode, ud_insn_hex(&cptr->ud_obj),(unsigned char)raw[0]);
                deladdr(sys,origaddr, 1);
            }
        } else {
            printf("code_add(%lu:%d) not adding. already in database\n", origaddr, size);
            return NULL;
        }
    }
    
    if ((cptr = (CODE *)l_add((LINK **)&sys->code, sizeof(CODE))) == NULL) {
        printf("code_add() - error allocating cptr\n");
        exit(-1);
    }
    
    cptr->offset = offset;
    cptr->fileoffset = fileoffset;
    cptr->size = size;
    cptr->oldaddr = origaddr;
    cptr->asmcode = strdup(asmcode);
    
    cptr->raw = mymalloc(cptr->size);
    memcpy(cptr->raw, raw, cptr->size);
    
    cptr->origaddr = origaddr;
    memcpy(&cptr->ud_obj, ud_obj, sizeof(ud_t));
    
    // set map for each byte
    for (i = 0; i < size; i++) {
        if ((fileoffset+i < sys->exe_size) && ((fileoffset+i) > 0))
            sys->map[fileoffset + i] = cptr;
    }
    
//    if (replace==1) {
        for (i = 0; realign[i] != NULL; i++) {
            if (strstr(asmcode, realign[i]) != NULL) {
                found = 1;
                // registers dont need to be realigned
                if (ud_obj->operand[0].type == UD_OP_REG) continue;
                //if (ud_obj->operand[0].type == UD_OP_MEM) continue;

                unsigned long toaddr = destaddr(cptr);
                if (toaddr != 0) {
                    queue_add(sys,toaddr, cptr);
                    //if (cptr->prev) printf("\t%lu\t\tbefore call: %s\n", cptr->prev->origaddr, cptr->prev->asmcode);
                    printf("\t%lu\t\trealign %lu code: %s\n\t\t\t\top type %d size %d scale %d index %d[", origaddr, destaddr(cptr), asmcode, ud_obj->operand[0].type, ud_obj->operand[0].size, ud_obj->operand[0].scale, ud_obj->operand[0].index);
                    for (i = 0; i < size; i++) { printf("%02x ", (unsigned char *)raw[i]); } printf("]\n");
                    cptr->toaddr = toaddr;
                    cptr->realign = 1;
                    if (strstr(asmcode, "call") != NULL) {
                        cptr->call = 1;
                        fptr = Func_Add(sys, toaddr);
                        rptr = (Ref *)l_add((LINK **)&fptr->refs, sizeof(Ref));
                        rptr->refptr = cptr;
                    }
                }
                
                //cptr->realign = 1;

                
                //rptr = (Ref *)l_add((LINK **)&cptr->refs, sizeof(Ref));
                //rptr->refptr = cptr;
                break;
                
            }
            if (strcmp(asmcode, "mov ebp, esp")==0) {
                Func_Add(sys, origaddr - 1); // go to push ebp infront of mov ebp, esp
            }
        }
   // }
    
    return cptr;
    
}

// finds the CODE structures for distance between a jmp and it's possible new address (if we inserted code)
long distance(System *sys, unsigned long addr, unsigned long addr2, int depth) {
    CODE *cptr, *cptr2;
    long diff;
    
    cptr= findaddr(sys,addr);
    diff = addr + cptr->size;
    if (cptr == NULL) {
        printf("!error dist %x and %x\n", addr, addr2);
        exit(-1);
    }
    
    for (cptr2 = sys->code; cptr2 != NULL; cptr2 = cptr2->next) {
        if ((addr2 >= (cptr2->oldaddr + cptr2->size)) && (addr2 < (cptr2->oldaddr + cptr2->size)))
            return cptr2->origaddr - (addr + cptr->size);
    }
    
    //int analyze(System *sys, unsigned long addr, int retstop, unsigned long end_eip, int max_instr, int replace) {
    for (cptr2 = sys->code; cptr2 != NULL; cptr2 = cptr2->next) {
        if (cptr2->oldaddr == addr2) {
            return cptr2->origaddr - (addr + cptr->size);
        }
    }


    // maybe analyze here if not found
    
    if (!depth) {
        analyze(sys, addr - 16,  1, 0, 50, 1);
        analyze(sys, addr2 - 16,  1, 0, 50, 1);
        return distance(sys, addr, addr2, 1);
    }
    
    printf("error distance %x and %x\n", addr, addr2);
    return 0;
}

// insert code at a specific address (give the addresses CODE structure)
System *code_insert(System *sys, CODE *cptr, int remove_orig, int before) {
    unsigned char *newbin;
    FILE *fd;
    struct stat stv;
    System *newsys;
    Section *sptr, *nextsptr;
    CODE *newcodes = NULL;
    CODE *newcptr, *newcptr2;
    CODE *cptr2, *cptr3;
    unsigned long addr, addr2;
    unsigned long addr_warp = 0;
    PIMAGE_SECTION_HEADER pish;
    PIMAGE_NT_HEADERS pinh;
    unsigned long base;
    
    fd = fopen("inject.bin","rb");
    fstat(fileno(fd), &stv);
    newbin = mymalloc(stv.st_size + 1);
    fread(newbin, stv.st_size, 1, fd);
    fclose(fd);
    stv.st_size -= 7;
    
    if (cptr == NULL) { printf("err\n"); return NULL; }
    newcptr = (CODE *)l_add((LINK **)&cptr->additions, sizeof(CODE));
    newcptr->size = stv.st_size;
    newcptr->raw = newbin;
    
    cptr->additional_before = 1;
    
    // find code section
    for (sptr = sys->sections; sptr != NULL; sptr = sptr->next)
        if (sptr->entrysect == 1) break;

/*
    // increase section size (should be changed later to realign all sections)
    sptr->size += newcptr->size;
    
    pish = (PIMAGE_SECTION_HEADER)&sptr->rawheader;
    pish->SizeOfRawData += newcptr->size;

 
    // find next sections to increase their RVA
    for (nextsptr = sptr->next; nextsptr != NULL; nextsptr = nextsptr->next) {
        pish = (PIMAGE_SECTION_HEADER)&nextsptr->rawheader;
        pish->PointerToRawData += newcptr->size;
        nextsptr->rva += newcptr->size;
        base = nextsptr->vaddr + (4096 * 3);
    }
    
    pish = (PIMAGE_SECTION_HEADER)&sptr->rawheader;
//    pish->VirtualAddress = base;
//    sptr->vaddr = base;
 
    pinh = (PIMAGE_NT_HEADERS)(sys->pntheader);
    pinh->OptionalHeader.AddressOfEntryPoint = (pinh->OptionalHeader.AddressOfEntryPoint - sptr->vaddr) + base;

    
   /* // change some other headers

    printf("A %d %d %x\n", pinh->OptionalHeader.SizeOfCode, pinh->OptionalHeader.BaseOfData, pinh->OptionalHeader.SizeOfCode);
    
    pinh->OptionalHeader.SizeOfCode += ( newcptr->size);
    pinh->OptionalHeader.BaseOfData += newcptr->size;
    pinh->OptionalHeader.SizeOfImage += (newcptr->size);
    pinh->FileHeader.PointerToSymbolTable += newcptr->size;
    
    printf("B %d %d %x\n", pinh->OptionalHeader.SizeOfCode, pinh->OptionalHeader.BaseOfData, pinh->OptionalHeader.SizeOfCode);
*/
    
//    memset(sys->header, 0, 32);
    //printf("sptr size %d\n", sptr->size);

//    memset(sptr->rawheader, 0x90, 32);
    // rebuild exe in a new structure
    // loop through code section
    for (addr = addr2 = sptr->vaddr; addr2 < (sptr->vaddr + sptr->size); ) {
        if ((cptr2 = findaddr(sys, addr2)) == NULL) {
            //printf("copy [%lu %lu] not found\n", addr2, addr);
            addr2++;
            addr++;
            continue;
        } //else printf("copy [%lu %lu] found %d\n", addr2, addr, cptr2->realign);

            for (cptr3 = cptr2->additions; cptr3 != NULL; cptr3 = cptr3->next) {
                printf("[%lu] additions found %lu %d\n", cptr2->origaddr, cptr3->raw, cptr3->size);
                newcptr2 = (CODE *)l_add((LINK **)&newcodes, sizeof(CODE));
                newcptr2->raw = mymalloc(cptr3->size + 1);
                memcpy(newcptr2->raw, cptr3->raw, cptr3->size);
            
                //newcptr2->asmcode = strdup(cptr3->asmcode);
                newcptr2->offset = addr;
                newcptr2->origaddr = addr;
                newcptr2->size = cptr3->size;
                memcpy(&newcptr2->ud_obj, &cptr3->ud_obj, sizeof(ud_t));
                
                addr += newcptr2->size;
                addr_warp += newcptr2->size;
                printf("%lu %d %d\n", addr, addr_warp, cptr3->size);
            }
            
    
        
       /* if (cptr2->remove==1) {
            printf("[%lu] remove\n", cptr2->origaddr);
            addr_warp -= cptr2->size;
            addr2 += cptr2->size;
            continue;
        }*/
        newcptr = (CODE *)l_add((LINK **)&newcodes, sizeof(CODE));
        newcptr->raw = mymalloc(cptr2->size + 1);
        memcpy(newcptr->raw, cptr2->raw, cptr2->size);
        
        newcptr->asmcode = strdup(cptr2->asmcode);
        newcptr->offset = addr;
        newcptr->origaddr = addr;
        newcptr->oldaddr = addr2;
        newcptr->size = cptr2->size;
        newcptr->realign = cptr2->realign;
        newcptr->toaddr = cptr2->toaddr;
        memcpy(&newcptr->ud_obj, &cptr2->ud_obj, sizeof(ud_t));
        
//        printf("%d %u\n", newcptr->realign, newcptr->toaddr);
        
        addr += cptr2->size;
        addr2 += cptr2->size;
    }
    
    //sptr->vaddr = base;
    
    
    sys->oldcode = sys->code;
    sys->code = newcodes;
    sptr->size += addr_warp;
    
    return sys;
}

// loop through all CODE structures rewriting the addresses for realignment
int realignshit(System *sys) {
    CODE *cptr;
    long _distance=0;
    
    for (cptr = sys->code; cptr != NULL; cptr = cptr->next) {
        if (!cptr->realign) continue;
        _distance = distance(sys, cptr->origaddr, cptr->toaddr, 0);
        printf("realignment distance between %lu & %lu [%s] %d current %d\n",
               cptr->origaddr,cptr->toaddr, cptr->asmcode, _distance, cptr->ud_obj.operand[0].lval.sdword);
        //,cptr->ud_obj.operand[0].size,
          //     cptr->toaddr, _distance);
        
        if (_distance != 0)
        switch (cptr->ud_obj.operand[0].size) {
            case 8:
                cptr->ud_obj.operand[0].lval.sbyte = _distance;
                memcpy(cptr->raw+1, &cptr->ud_obj.operand[0].lval.sbyte, 1);
                break;
            case 16:
                cptr->ud_obj.operand[0].lval.sword = _distance;
                memcpy(cptr->raw+2, &cptr->ud_obj.operand[0].lval.sword, 2);
                break;
            case 32:
                cptr->ud_obj.operand[0].lval.sdword  = _distance;
                memcpy(cptr->raw+1, &cptr->ud_obj.operand[0].lval.sdword, 4);
                break;
        } 
    }
    return 0;
}

unsigned long findfreespace(System *sys, unsigned long start, unsigned long end,  int *size) {
    unsigned long addr = start;
    int _size = 0;
    char blah[8];
    unsigned long ret = 0;
    
    for (;addr < end; addr += 8) {
        MemDataRead(sys, addr, &blah, 8);
        if (memcmp(blah, "\0\0\0\0\0\0\0\0", 8)==0) {
            ret = addr;
            break;
        }
    }
    if (ret != 0) {
        while (addr < end) {
            MemDataRead(sys, addr, &blah, 1);
            if (blah[0] != 0) break;
            _size++;
            addr++;
        }
        *size = _size;
    }
    return ret;
}

// dump CODE structures to file for debugging
int CODE_dump(System *sys, char *file) {
    FILE *fd;
    CODE *cptr;
    fd = fopen(file,"w");
    for (cptr = sys->code; cptr != NULL; cptr = cptr->next) {
    }
}

