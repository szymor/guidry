void codeunlink(CODE *cptr);
CODE *findaddr(System *sys, void *addr);
void deladdr(System *sys, void *addr, int size);
CODE *code_add(System *sys, int offset, int fileoffset, unsigned long origaddr, int size, unsigned char *asmcode, unsigned char *raw, int replace, ud_t *ud_obj);
System *code_insert(System *sys, CODE *cptr, int remove_orig, int before);
long distance(System *sys, unsigned long addr, unsigned long addr2);
int realignshit(System *sys);