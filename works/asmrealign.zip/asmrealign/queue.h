int queue_analyze(System *sys);
int queue_size(System *sys);
Queue *queue_add(System *sys, unsigned long addr, CODE *cptr);