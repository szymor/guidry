#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include "structs.h"
#include "vmem.h"
#include "links.h"
#include "pe.h"
#include <sys/stat.h>
#include "code.h"
#include "utils.h"

#pragma pack(1)

#define IMAGE_ORDINAL_FLAG32 0x80000000
#define IMAGE_SNAP_BY_ORDINAL(ordinal) (((ordinal) & IMAGE_ORDINAL_FLAG32) != 0)

Section *sections = NULL;

Section *Section_FindByRVA(System *sys, unsigned long addr) {
    Section *sptr;
    for (sptr = sys->sections; sptr != NULL; sptr = sptr->next) {
        if ((addr >= sptr->rva) && (addr < (sptr->rva + sptr->size))) {
            return sptr;
        }
    }
    return NULL;
}

Section *Section_FindByAddr(System *sys, unsigned long addr) {
    Section *sptr;
    
    for (sptr = sys->sections; sptr != NULL; sptr = sptr->next) {
        if ((addr >= sptr->addr) && (addr < (sptr->addr + sptr->size))) {
            return sptr;
        }
    }
    return NULL;
}

//   This function is also Pietrek's
void *GetPtrFromRVA(System *sys, unsigned long rva) {
    Section *sptr;
    unsigned long delta;
    
    rva = rva & 0x7fffffff;
    
    if ((sptr = Section_FindByAddr(sys, rva)) == NULL) {
        printf("error finding section for rva %lx\n", rva);
        return NULL;
        exit(-1);
        //return (unsigned long)(sys->exe) + (unsigned long)rva;
    }
    
    //printf("found rva %d in section %s [%lu %d]\n", rva, sptr->name, sptr->addr, sptr->size);
    
    delta = sptr->addr - sptr->rva;
    
    return (void *)(sys->exe + (rva - sptr->addr + sptr->rva));
}


Section *PEParse(System *sys, char *filename) {
    int i;
    PIMAGE_DOS_HEADER pidh;
    PIMAGE_NT_HEADERS pinh;
    PIMAGE_SECTION_HEADER pish;
    PIMAGE_IMPORT_DESCRIPTOR impdesc;
    PIMAGE_IMPORT_BY_NAME thunkname;
    PIMAGE_THUNK_DATA origthunk, firstthunk, addrthunk;
    DLL *dll = NULL, *dlls = NULL;
    DLLFunc *dllfunc = NULL;
    int desccount = 0;
    Section *sptr;
    Section *entrys = NULL, *ret = NULL;
    unsigned short hintindex;
    char *name;
    int d = 0;
    
    FILE *fd;
    struct stat stv;
    
    if ((fd = fopen(filename,"rb")) == NULL) {
        printf("main: couldn't open %s\n", filename);
        exit(-1);
    }
    
    fstat(fileno(fd), &stv);
    sys->exe = mymalloc(stv.st_size);
    
    fread(sys->exe, stv.st_size, 1, fd);
    fclose(fd);
    
    sys->exe_size = stv.st_size;
    printf("Loaded %s into memory [%ld bytes at %p]\n", filename, stv.st_size, sys->exe);

    sys->map = mymalloc(sizeof(CODE) * stv.st_size);
    
    printf("Verifying DOS+NT signatures..");
	pidh = (PIMAGE_DOS_HEADER)sys->exe;
    if(pidh->e_magic != IMAGE_DOS_SIGNATURE) {
        printf("No dos signature\n");
        exit(-1);
    }
    pinh = (PIMAGE_NT_HEADERS)(sys->exe + pidh->e_lfanew);
    if(pinh->Signature != IMAGE_NT_SIGNATURE) {
        printf("SectionParse: no nt signature\n");
        exit(-1);
    }
    printf("Done.\n");
    

    sys->header = (unsigned char *)mymalloc(pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS));
    memcpy(sys->header, sys->exe, pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS));
    sys->pntheader =  (PIMAGE_NT_HEADERS)(sys->header + pidh->e_lfanew);

    
    sys->baseaddr = pinh->OptionalHeader.ImageBase;
    sys->entry = pinh->OptionalHeader.AddressOfEntryPoint;
    printf("PE Base Address %lx | Enrtry Point (Code) %lx [%lx]\n", sys->baseaddr, sys->entry, sys->baseaddr + sys->entry);
    
    printf("Iterating through each section and replicating into virtual memory.\n");
        
    for(i = 0; i < pinh->FileHeader.NumberOfSections; i++) {
        pish = (PIMAGE_SECTION_HEADER)(sys->exe + pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS) + sizeof(IMAGE_SECTION_HEADER) * i);
        
        if ((sptr = (Section *)l_add((LINK **)&sys->sections, sizeof(Section))) == NULL) {
            printf("SectionParse: error alloc section struct\n");
            exit(-1);
        }
        
        sptr->name = strdup(pish->Name);
        sptr->rva = pish->PointerToRawData;
        sptr->addr = pish->VirtualAddress;
        sptr->size = pish->SizeOfRawData;
        sptr->vaddr = sptr->addr + sys->baseaddr;
        // copy section data into buffer inside struct
        sptr->data = mymalloc(sptr->size);
        memcpy(sptr->data, sys->exe + sptr->rva, sptr->size);
        
        printf("---\nSection %d name %s\n", i, sptr->name);
        
        printf("Address: %lx-%lx [%lx-%lx] RVA %ld Size %ld\n", sptr->vaddr, sptr->vaddr + sptr->size,sptr->addr, sptr->addr + sptr->size ,sptr->rva, sptr->size);
        
        if (((sys->baseaddr+sys->entry) >= sptr->vaddr) && ((sys->baseaddr + sys->entry) < (sptr->vaddr + sptr->size))) {
            sptr->entrysect=1;
            entrys = sptr;
            sys->entrys = sptr;
            printf("Entry Point section\n");
            ret = sptr;
        }
        
        sptr->rawheader = mymalloc(sizeof(IMAGE_SECTION_HEADER));
        memcpy(sptr->rawheader, sys->exe + pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS) + sizeof(IMAGE_SECTION_HEADER) * i, sizeof(IMAGE_SECTION_HEADER));
        
        printf("Copying section into Virtual Memory.. %lx from %p size %lx\n", sptr->vaddr, sys->exe + sptr->rva, sptr->size);
        MemDataWrite(sys,sptr->vaddr, (unsigned char *)(sys->exe + sptr->rva), sptr->size);
    }
    
    sys->entryrva = ((sys->entry + sys->baseaddr) - (entrys->vaddr)) + entrys->rva;

    
    printf("\n--- Information\nEntry RVA: %lu Code Base RVA %ul Base Data %ul\n", sys->entryrva, pinh->OptionalHeader.BaseOfCode,
           pinh->OptionalHeader.BaseOfData);
    
    
    if (pinh->OptionalHeader.DataDirectory[1].VirtualAddress != 0) {
        
        sys->importsection = Section_FindByAddr(sys,pinh->OptionalHeader.DataDirectory[1].VirtualAddress);
        printf("Parsing DLL imports %d\n",pinh->OptionalHeader.DataDirectory[1].Size);
        desccount = (int)(pinh->OptionalHeader.DataDirectory[1].Size / sizeof(IMAGE_IMPORT_DESCRIPTOR));
        
        printf("des count %d %ld[%lx]\n", desccount, sizeof(IMAGE_IMPORT_DESCRIPTOR),sizeof(IMAGE_IMPORT_DESCRIPTOR));
        
        impdesc = GetPtrFromRVA(sys, pinh->OptionalHeader.DataDirectory[1].VirtualAddress + (sizeof(IMAGE_IMPORT_DESCRIPTOR) * d));
        
        while (impdesc->Name && impdesc->FirstThunk) {
                if (impdesc->OriginalFirstThunk) // name table
                    firstthunk = (PIMAGE_THUNK_DATA)GetPtrFromRVA(sys,impdesc[d].OriginalFirstThunk);
                else
                    firstthunk = (PIMAGE_THUNK_DATA)GetPtrFromRVA(sys,impdesc[d].FirstThunk);
            
                addrthunk = impdesc[d].FirstThunk;
            
                printf("\n----\nDLL \"%s\" OriginalFirst: %ul First %ul TimeStamp %ul Forward %ul\n", (char *)GetPtrFromRVA(sys, (char *)impdesc[d].Name),
                       impdesc[d].OriginalFirstThunk, impdesc[d].FirstThunk, impdesc[d].TimeDateStamp, impdesc[d].ForwarderChain);
            
            dll = (DLL *)l_add((LINK **)&sys->imports, sizeof(DLL));
            dll->name = strdup(GetPtrFromRVA(sys, impdesc[d].Name));
            dll->rva = impdesc;
            
            if (!firstthunk->u1.Function) {
                printf("no first thunk.. skip\n");
                goto skipimport;
            }
            
            while (firstthunk->u1.Ordinal != 0 && firstthunk->u1.AddressOfData != 0) {
                    if (IMAGE_SNAP_BY_ORDINAL(firstthunk->u1.Ordinal)) {
                        printf("ordinal %x not supported\n", firstthunk->u1.Ordinal);
                        exit(-1);
                    
                    } else {
                        if ((thunkname = (PIMAGE_IMPORT_BY_NAME)GetPtrFromRVA(sys,firstthunk->u1.AddressOfData)) != NULL) {
                            if (thunkname->Name[0] == 0) {
                                break;
                            }
                            if ((name = GetPtrFromRVA(sys,firstthunk->u1.AddressOfData)) != NULL) {
                                name += 2;
                                printf("Name: %s %p \n",(char *) name, (void *)addrthunk);
                                dllfunc  = (DLLFunc *)l_add((LINK **)&dll->funcs, sizeof(DLLFunc));
                                dllfunc->name = strdup(name);
                                dllfunc->rva = addrthunk;
                                
                            } else {
                                printf("Cannot get name from thunk data %lu\n", firstthunk->u1.AddressOfData);
                                printf("maybe broke?\n");
                                //exit(-1);
                            }
                        } else {
                            printf("thunk name == null.. maybe broke?\n");
                            //exit(-1);
                        }
                    }
                firstthunk++;
                addrthunk++;
                
            }
            skipimport:;
            impdesc++;
        }
    }
    

    for (dll = sys->imports; dll != NULL; dll = dll->next) {
        for (dllfunc = dll->funcs; dllfunc != NULL; dllfunc = dllfunc->next) {
            printf("DLL %s FUNC %s [%lu] [%lu]\n", dll->name, dllfunc->name, dllfunc->rva, dllfunc->rva + sys->baseaddr);
        }
    }
    
    // HACK to find beginning of Data so we can be sure we don't loop forever analyzing non-code
    
    dll = sys->imports;
    dllfunc = dll->funcs;
    sys->end_eip = dllfunc->rva + sys->baseaddr;//sptr->vaddr;//(sptr->rva - sys->entryrva) + entrys->vaddr;
    printf("end_eip = %lu\n", sys->end_eip);
    

   // exit(-1);
    

    return ret;
}

int WritePE(System *sys,  char *output)
{
    int i;
    int buf_i;
    struct stat stv;
    PIMAGE_DOS_HEADER pidh;
    PIMAGE_NT_HEADERS pinh;
    PIMAGE_SECTION_HEADER pish;
    
    unsigned char *ibuf, *obuf, *optr;
    FILE *ifd, *ofd;
    
    Section *sptr = sys->sections;
    
    CODE *cptr;
    unsigned long addr;
    
    unlink(output);
    
    if ((ofd = fopen(output,"wb")) == NULL) {
        printf("WritePE couldnt open output file\n");
        exit(-1);
    }
    
    pidh = (PIMAGE_DOS_HEADER)sys->header;
    if(pidh->e_magic != IMAGE_DOS_SIGNATURE) {
        printf("No dos signature\n");
        exit(-1);
    }
    
    pinh = (PIMAGE_NT_HEADERS)(sys->header + pidh->e_lfanew);
    if(pinh->Signature != IMAGE_NT_SIGNATURE) {
        printf("no nt signature\n");
        exit(-1);
    }
    
//    pinh->OptionalHeader.CheckSum = 0;

    obuf = optr = mymalloc(1024 * 1024 * 5);
  
    // begin the PE with NT headers
    memcpy(optr, sys->header, pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS));
    optr += (pidh->e_lfanew + sizeof(IMAGE_NT_HEADERS));
    
    // now put the section headers
    for (sptr = sys->sections; sptr != NULL; sptr = sptr->next) {
        memcpy(optr, sptr->rawheader, sizeof(IMAGE_SECTION_HEADER));
        optr += sizeof(IMAGE_SECTION_HEADER);
    }
    
    printf("optr size %d after sects [first sect rva %d]\n", optr-obuf, sys->sections->rva);
    
    // copy whatever behind section headers.. maybe resource headers
    memcpy(optr, sys->exe+(optr-obuf), sys->sections->rva - (optr-obuf));
    optr += sys->sections->rva - (optr-obuf);
    
    // copy sections from virtual memory into output exe buffer...
    for (sptr = sys->sections; sptr != NULL; sptr = sptr->next) {
        if (sptr->entrysect != 1) {
            MemDataRead(sys, sptr->vaddr, obuf+sptr->rva, sptr->size);
            optr += sptr->size;
        } else {
        // We rebuild the code section from our internal CODE structures..
        // so it includes any modifications
            printf("Rebuilding & Writing code from internal CODE database %lu %x\n", sptr->vaddr, sptr->size);
            for (addr = sptr->vaddr, buf_i = 0; addr < (sptr->vaddr + sptr->size); ) {
                cptr = findaddr(sys, addr);
                if (cptr == NULL) {
                    MemDataRead(sys, sptr->vaddr, optr++, 1);
                    addr++;
                    buf_i++;
                } else {
                    memcpy(optr, cptr->raw, cptr->size);
                    optr += cptr->size;
                    addr += cptr->size;
                }
            }
            printf("%d bytes not found in CODE database.. copied from virtual memory\n", buf_i);
        }
    }
    
    // find rva for 
    sptr = sys->sections;
    while (sptr->next != NULL) { sptr=sptr->next; }
    
    fwrite(obuf, sptr->rva + sptr->size, 1, ofd);
    fclose(ofd);
    return 0;
}