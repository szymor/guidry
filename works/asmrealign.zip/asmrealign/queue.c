
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include <sys/stat.h>
#include "links.h"
#include "pe.h"
#include "structs.h"
#include "vmem.h"
#include "udis86.h"



// adds an address that needs to be analyzed (disassembled from it as a starting point)
Queue *queue_add(System *sys, unsigned long addr, CODE *cptr) {
    Queue *qptr;
    
    if (addr == 0) return NULL;
    
    for (qptr = sys->queue; qptr != NULL; qptr=qptr->next)
        if (qptr->addr == addr) return NULL;
    
    if ((qptr = (Queue *)l_add((Queue **)&sys->queue, sizeof(Queue))) == NULL) {
        printf("queue_add() error allocating queue\n");
        exit(-1);
    }
    
    printf("Queue add sys %lu addr %lu cptr %lu\n", sys, addr, cptr);
    qptr->addr = addr;
    qptr->calling_addr = cptr->origaddr;
    qptr->calling_ptr = cptr;
    
    return qptr;
}

// count the queue
int queue_size(System *sys) {
    return l_count((LINK *)sys->queue);
}

//loop through queue analyzing things
int queue_analyze(System *sys) {
    int count = 0;
    Queue *qptr;
    CODE *cptr;
    int n;
    for (qptr = sys->queue; qptr != NULL; qptr = qptr->next) {
        printf("queue loop %lu analyzed %d\n", qptr->addr, qptr->analyzed);
        if (qptr->analyzed == 1) continue;
        
        if (qptr->addr > sys->end_eip) {
            printf("%lu is higher than end_eip %lu\n", qptr->addr, sys->end_eip);
            continue;
            
        }
        
        cptr = findaddr(sys, qptr->addr);
        if (cptr == NULL) {
            printf("queue_analyze() analyzing new unseen location - %lu [from %lu / %s]\n", qptr->addr, qptr->calling_ptr->origaddr, qptr->calling_ptr->asmcode);
            analyze(sys, qptr->addr, 1, 0, 5000, 1);
            cptr = findaddr(sys, qptr->addr);
            //continue;
        }
        // verify that the address is within the code range
        if (!(
              (cptr->origaddr > ((unsigned long)sys->baseaddr + (unsigned long)sys->code_addr)) &&
              (cptr->origaddr < ((unsigned long)sys->baseaddr + (unsigned long)sys->code_addr + (unsigned long)sys->code_size)))) {
            //printf("queue address %lu is not within our ranges.. skipping\n", cptr->origaddr);
            // continue;
        }
        if (!cptr->analyzed) {
            cptr->analyzed = qptr->analyzed = 1;
            printf("\n\nqueue_analyze() analyze() %lu [from %lu - %s]\n", cptr->origaddr,qptr->calling_ptr->origaddr, qptr->calling_ptr->asmcode);
            analyze(sys, cptr->origaddr, 1, 0, 5000, 1);
            count++;
        }
    }
    printf("queue_analyze() total %d\n", count);
    return count;
}
