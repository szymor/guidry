#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "links.h"
#include "utils.h"



LINK *l_last(LINK *start) {
	LINK *lptr = start;

	while ((lptr != NULL) && (lptr->next != NULL))
		lptr = lptr->next;

	return lptr;

}

LINK *l_link(LINK **list, LINK *obj) {
	LINK *lptr;

	if (*list != NULL) {
		lptr = (LINK *)l_last(*list);
		lptr->next = obj;
        obj->prev = lptr;
	} else
		*list = obj;

	return obj;
}


LINK *l_add(LINK **list, int size) {
	LINK *newptr;

	if ((newptr = (LINK *)mymalloc(size)) == NULL)
		return NULL;

	memset(newptr, 0, size);
	return l_link(list, newptr);
}


void l_unlink(LINK **l_ptr, LINK *rem) {
	LINK *cur = *l_ptr, *last = rem;

	if (*l_ptr == rem) {
		if (cur->next != NULL)
			*l_ptr = cur->next;
		else
			*l_ptr = NULL;

	} else {
		while ((cur != NULL) && (cur != rem)) {
		  last = cur;

		  cur = cur->next;
		}

		if (cur == NULL) {
			return;
		}

		if (cur->next != NULL)
			last->next = cur->next;
		else
			last->next = NULL;
	}
}



void l_del(LINK **l_ptr, LINK *rem) {
	l_unlink(l_ptr, rem);

	free(rem);
}



int l_count(LINK *l_ptr) {
	int i = 0;

	while (l_ptr != NULL) {
		i++;

		l_ptr = l_ptr->next;
	}

	return i;
}
