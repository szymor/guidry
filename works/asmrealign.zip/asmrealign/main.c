#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include <sys/stat.h>
#include "links.h"
#include "pe.h"
#include "structs.h"

#include "vmem.h"
#include "udis86.h"
#include "disasm.h"
#include "queue.h"



int main(int argc, char *argv[]) {
    int n = 0;
    FILE *fd;
    struct stat stv;
    PIMAGE_DOS_HEADER pidh;
    PIMAGE_NT_HEADERS pinh;

    Section *entrys;
    unsigned long eip, eip_i, d_count=0;
    ud_t ud_obj;
    CODE *cptr;
    unsigned long freespace = 0;
    unsigned long freesize = 0;
    System *mainsys;
    unsigned long faddr; unsigned long faddr_end;
    unsigned long ffound;
    int i,count = 0;
    Funcs *fptr;
    
    mainsys = (System *)mymalloc(sizeof(System));
    memset(mainsys, 0, sizeof(System));
    
    if ((entrys = PEParse(mainsys, argv[1])) == NULL) {
        printf("PEParse(%s) failed\n", argv[1]);
        exit(-1);
    }
    
    
    //printf("---\n\nDism first run.. \n");
    //analyze(mainsys, entrys->vaddr, 0, mainsys->end_eip, entrys->size, 0);
    
    printf("Disasm() second run from entry point.. in case the disassembler was unaligned\n");
    analyze(mainsys, mainsys->baseaddr + mainsys->entry,  1, 0, 5000, 1);
    printf("\n---\nFinished disassembling entry point..\n");

    
    printf("Queue length for further analysis: %d addresses\n", queue_size(mainsys));
    
    printf("Beginning analysis loop\n");
    while (queue_analyze(mainsys)) {
        printf("looped queue_analyze()\n");
    }

    //printf("---\n\nDism third and final run.. just in case we missed some bytes\n");
    //analyze(mainsys,entrys->vaddr,  0, mainsys->end_eip, entrys->size, 0);

    
    printf("1. printing code which needs alignment:\n");
    for (cptr = mainsys->code; cptr != NULL; cptr= cptr->next) {
        if (cptr->realign) {
            printf("[%lu] %s\n", cptr->origaddr, cptr->asmcode);
            n++;
        }
    }
    printf("%d addresses might need alignment\n", n);
    
    
    for (fptr = mainsys->funcs; fptr; fptr = fptr->next) {
        fptr->size = analyze(mainsys, fptr->addr,  1, 0, 5000, 1);
        printf("func at %lud size %ld\n", fptr->addr, fptr->size);
    }
    for (fptr = mainsys->funcs; fptr; fptr = fptr->next) {
        fptr->size = analyze(mainsys, fptr->addr,  1, 0, 5000, 1);
        printf("func at %lu size %ld ref count: %d\n", fptr->addr, fptr->size, l_count((LINK *)&fptr->refs));
    }

    /*
    faddr_end = (mainsys->entrys->vaddr + mainsys->entrys->size);
    faddr = (mainsys->entrys->vaddr);
    
    while (ffound = findfreespace(mainsys, faddr, faddr_end, &freesize)) {
        printf("found free space at %lu size %d\n", ffound, freesize);
        faddr = ffound + freesize;
    }*/
    
//    freespace = findfreespace(mainsys, mainsys->entrys, &freesize);
    
    //printf("Inserting new code\n");
    code_insert(mainsys, findaddr(mainsys, mainsys->baseaddr + mainsys->entry), 0, 1);
    
    for (i = 0; i < mainsys->exe_size; i++) {
        if (mainsys->map[i] != NULL) count++;
        
    }
    
   // printf("coverage %d / %d %d\n", count, mainsys->entrys->size, l_count((LINK *)mainsys->funcs));
    
    //exit(-1);

    n = 0;
    printf("2. printing code which needs alignment:\n");
    for (cptr = mainsys->code; cptr != NULL; cptr= cptr->next) {
        if (cptr->realign==1) {
            printf("[%lu] %s ALN\n", cptr->origaddr, cptr->asmcode);
            n++;
        }
    }
    printf("%d addresses might need alignment\n", n);

    printf("realign shit\n");
    realignshit(mainsys);
    printf("Writing output PE\n");
    
    WritePE(mainsys,  "output.exe");

    return 0;
} 
