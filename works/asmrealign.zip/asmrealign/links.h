

typedef struct _link { struct _link *next; struct _link *prev; } LINK;



LINK *l_last(LINK *);

LINK *l_add(LINK **, int);

void l_del(LINK **, LINK *);

int l_count(LINK *);

LINK *l_link(LINK **, LINK *);

void l_unlink(LINK **, LINK *);
