void *mymalloc(size_t size);
void myfree(void *ptr);