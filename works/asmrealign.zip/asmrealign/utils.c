#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <udis86.h>
#include "structs.h"
#include "vmem.h"
#include "links.h"
#include "pe.h"
#include <sys/stat.h>
#include "code.h"

void *mymalloc(size_t size) {
    void *ret;
#ifndef WIN32
    if ((ret = malloc(size + 1)) == NULL) {
        printf("malloc(%d) error\n", size);
        exit(-1);
    }
    memset(ret, 0, size);
    
#else
    if ((ret = (void *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY)) == NULL) {
        printf("HeapAlloc(%d) error\n", size);
        ExitProcess(0);
    }
#endif
    return ret;
}

void myfree(void *ptr) {
#ifndef WIN32
    free(ptr);
#else
    HeapFree(GetProcessHeap(), 0, ptr);
#endif
    return;
}