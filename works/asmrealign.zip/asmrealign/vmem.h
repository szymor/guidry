#ifndef _VMEM_H
#define _VMEM_H
typedef struct _memory_page {
    struct _memory_page *next;
    struct _memory_page *prev;
    unsigned long addr;
    unsigned long high_addr;
    unsigned long round;
    int size;
    unsigned char *data;
} MemPage;

unsigned char *MemDataRead(System *sys, unsigned long addr, unsigned char *result, int len);
unsigned long MemDataWrite(System *sys,unsigned long addr, unsigned char *data, int len);
MemPage *MemPagePtr(System *sys, unsigned long addr);



#endif
