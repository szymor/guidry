#ifndef _STRUCT_H
#define _STRUCT_H
typedef struct __code {
    struct __code *next;
    struct __code *prev;
    int fileoffset;
    int offset;
    unsigned char *raw;
    unsigned short size;
    int realign;
    unsigned long toaddr;
    void *refs;
    struct __code *additions;
    int additional_before;
    unsigned char *asmcode;
    int remove;
    ud_t ud_obj;
    unsigned long origaddr;
    int analyzed;
    unsigned long oldaddr;
        int call;
} CODE;

typedef struct _queue {
    struct _queue *next;
    struct _queue *prev;
    unsigned long addr;
    unsigned long calling_addr;
    CODE *calling_ptr;
    int analyzed;

} Queue;


typedef struct _section {
    struct _section *next;
    struct _section *prev;
    unsigned long addr;
    unsigned long size;
    unsigned long rva;
    unsigned long vaddr;
    char *name;
    int entrysect;
    unsigned char *data;
    unsigned long oldbase;
    // for when we rewrite to new pe
    void *rawheader;
} Section;

typedef struct _system {
    struct _system *next;
    struct _system *prev;
    Queue *queue;
    CODE *code;
    CODE **map;
    CODE *oldcode;
    unsigned long end_eip;
    
    unsigned char *header;
    unsigned char *exe;
    int exe_size;
    int header_size;
    int start_raw;
    unsigned long baseaddr;
    unsigned long entry;
    int code_size;
    unsigned long code_addr;
    unsigned long entryrva;
    Section *sections;
    void *pages;
    void *pntheader;
    Section *entrys;
    void *imports;
    void *funcs;
    Section *importsection;
} System;

typedef struct _ref {
    struct _ref *next;
    struct _rev *prev;
    CODE *refptr;
} Ref;


typedef struct _dllfuncs {
    struct _funcs *next;
    struct _funcs *prev;
    char *name;
    unsigned long rva;
} DLLFunc;

typedef struct _imports {
    struct _imports *next;
    struct _imports *prev;
    //char *dll;
    char *name;
    DLLFunc *funcs;
    unsigned long rva;
} DLL;

typedef struct _funcs {
    struct _funcs *next;
    struct _funcs *prev;
    unsigned long addr;
    unsigned long size;
    unsigned long ret;
    unsigned long refcount;
    unsigned long oldaddr;
    Ref *refs;
    int id;
    char **asmcode;
} Funcs;


#endif